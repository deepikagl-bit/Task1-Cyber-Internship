# Interview Questions & Answers

Q1. What is an open port?
An open port is a network port on a device that is accepting connections; a service or application is listening on that port.

Q2. How does Nmap perform a TCP SYN scan?
Nmap sends a TCP SYN packet to the target port. If the target replies with SYN-ACK, the port is open; if it replies with RST, the port is closed. Nmap then typically sends an RST to avoid completing the TCP handshake.

Q3. What risks are associated with open ports?
Open ports can expose services that attackers may probe for vulnerabilities, perform brute-force attacks, or exploit to gain unauthorized access.

Q4. Explain the difference between TCP and UDP scanning.
TCP scanning is connection-oriented and detects open/closed ports reliably. UDP scanning is connectionless, often silent (no response), and can produce false negatives/slow results.

Q5. How can open ports be secured?
Close unused services, restrict access with firewall rules, use strong authentication, apply patches, and employ encryption where possible.

Q6. What is a firewall's role regarding ports?
A firewall filters network traffic and can block or allow access to specific ports and services based on defined rules, reducing exposure.

Q7. What is a port scan and why do attackers perform it?
A port scan probes a host to discover which ports are open. Attackers use it for reconnaissance to find potential entry points.

Q8. How does Wireshark complement port scanning?
Wireshark captures network packets for detailed analysis, which helps validate scan findings and inspect the actual traffic and protocols in use.
