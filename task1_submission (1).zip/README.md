# Task 1 - Cyber Security Internship

## Objective
Discover open ports on devices in your local network to understand network exposure.

## Tools Used
- Nmap (port scanning)
- Wireshark (optional, packet analysis)

## Steps Performed
1. Installed Nmap from the official website.
2. Found local IP range using `ipconfig` (Windows) / `ifconfig` or `ip a` (Linux). Example: `192.168.1.0/24`.
3. Ran TCP SYN scan:
```
nmap -sS 192.168.1.0/24
```
4. Collected scan results (IP addresses + open ports).
5. Analyzed services running on open ports (like SSH, HTTP, SMB, MySQL).
6. Identified potential security risks of those ports.
7. Exported scan results to text:
```
nmap -sS 192.168.1.0/24 -oN scan_results.txt
```

## Findings (example)
- 192.168.1.1 → 80 (HTTP), 443 (HTTPS)
- 192.168.1.10 → 22 (SSH)
- 192.168.1.15 → 139 (NetBIOS), 445 (SMB)

## Risks Identified
- Open SSH/SMB ports may be targeted for brute-force attacks.
- HTTP without HTTPS exposes data.
- Excessive open ports increase attack surface.

## Security Measures
- Close unused ports.
- Configure firewall rules.
- Enable authentication and encryption.
- Monitor network with IDS/IPS.

## Files Included
- scan_results.txt
- interview_answers.md
- proof_placeholder.txt
- README.md (this file)
